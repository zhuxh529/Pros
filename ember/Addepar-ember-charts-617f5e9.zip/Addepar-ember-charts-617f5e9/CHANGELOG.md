# Ember Charts Changelog

### Ember Charts 0.1.0 _(June 20, 2014)_

* Initial release
