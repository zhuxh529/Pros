ember-addepar-mixins
====================

Extend Ember with some useful mixins
